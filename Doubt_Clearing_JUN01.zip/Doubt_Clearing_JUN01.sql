USE sakila ;

SELECT actor_id, first_name, last_name 
FROM actor 
WHERE first_name REGEXP 'john*' ;

SELECT actor_id, first_name
FROM actor 
WHERE first_name REGEXP '[0-9]' ;

SELECT first_name, SUBSTR(first_name,1,5) 
FROM actor ;

SELECT first_name, INSTR(first_name,'LOPE') 
FROM actor ;

SELECT first_name, LPAD(first_name, 15, "ABC"), RPAD(first_name, 15, "ABC"), REPEAT(first_name, 2)
FROM actor ;

/* total salary of individual where salary + commission = total salary 
for eg. salary of an employee is 1000rs and commission is 0.40% so 
total salary = 1000+400=1400 ; Treatment for NULL values ? */

USE hr;

SELECT * FROM employees; 

SELECT CONCAT(last_name,', ',first_name) as employee_name, salary, commission_pct,
(salary + (salary*COALESCE(commission_pct,0))) as total_salary
FROM employees;

----- Removing all spaces from a string 

SELECT CONCAT(last_name,', ',first_name) as employee_name, LENGTH(CONCAT(last_name,', ',first_name)),
REPLACE(CONCAT(last_name,', ',first_name),' ',''), LENGTH(REPLACE(CONCAT(last_name,', ',first_name),' ',''))
FROM employees;

SELECT location_id, street_address, 
SUBSTRING_INDEX(REPLACE(REPLACE(REPLACE(street_address,',',' '),')',' '),'(',' '),' ',-1) AS last_word ,
SUBSTRING_INDEX(REPLACE(REPLACE(REPLACE(street_address,',',' '),')',' '),'(',' '),' ',1)  
FROM locations;

-------------- Calculating % from multiple tables -----------

USE northwind;

select a.*, 
b.unitprice, b.quantity, d.UnitsInStock,
(b.quantity/d.UnitsInStock) as pc_units,
d.productname, 
d.categoryname, d.description,  
year(orderdate) as yr, month(orderdate) as mth
from orders a
left join
`order details` b on a.orderid = b.orderid
left join products c on b.productid = d.productid
left join categories d on d.categoryid = d.categoryid ;

----- slicing first word from the column containing a string if you have only one word how do we pick that
USE hr;

select department_name,
case when space_loc = 0 then department_name else left(department_name,space_loc-1) end as first_word
from
(
	SELECT department_name,
	LOCATE(' ',department_name) as space_loc
	FROM departments
) a ;

/*Write a query to display the length of first name 
for employees where last name contain character 'c' after 2nd position*/

SELECT first_name
		 ,LENGTH(first_name)
		 , last_name
FROM employees
WHERE last_name LIKE '__C%' ;

SELECT   first_name
		 ,LENGTH(first_name)
		 , last_name
FROM employees
WHERE INSTR(last_name,'C') > 2;

SELECT   first_name
		 ,LENGTH(first_name)
		 , last_name
FROM employees
WHERE substring(last_name,3) like '%c%';

-------- Subqueries ----------------

USE sakila;

SELECT a.title, a.rating, a.rental_amount, a.rnk
FROM
(
	SELECT title, rating, (rental_duration*rental_rate) AS rental_amount ,
	ROW_NUMBER() OVER (PARTITION BY rating ORDER BY (rental_duration*rental_rate) desc) as Rnk
	FROM film 
) a
WHERE a.Rnk = 1 ;

-- Data for top 10 products and top 3 customers

USE northwind;

select * from
(
	select *,
	row_number() over (partition by country order by sales desc) as customer_rnk
	from
	(
		select a.*, 
		b.unitprice, b.quantity, (b.unitprice * b.quantity) as sales, 
		d.productname, 
		e.companyname, e.contactname, e.contacttitle, e.country,  
		year(orderdate) as yr, month(orderdate) as mth
		from orders a
		left join
		`order details` b on a.orderid = b.orderid
		inner join 
		(select * from 	
			(
				select *,
				row_number() over (order by UnitPrice desc) as rnk
				from products
			) c 
		where rnk<11) d on b.productid = d.productid
		left join customers e on a.customerid = e.customerid 
	) tmp1 
) tmp2 
where customer_rnk < 4 ;

----- Top 10 products

select * from 	
	(
		select *,
		row_number() over (order by UnitPrice desc) as rnk
		from products
	) c 
where rnk<11 ;

